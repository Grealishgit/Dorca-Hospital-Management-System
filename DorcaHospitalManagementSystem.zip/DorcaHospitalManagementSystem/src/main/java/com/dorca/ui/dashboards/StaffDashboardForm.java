package com.dorca.ui.dashboards;







import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class StaffDashboardForm extends JFrame {
    private JLabel totalStaffLabel;
    private JLabel totalDepartmentsLabel;
    private JLabel totalPositionsLabel;

    // Database connection details
    private final String url = "jdbc:sqlserver://localhost:1433;databaseName=HospitalDB;encrypt=true;trustServerCertificate=true;";
    private final String dbUsername = "hunter";
    private final String dbPassword = "hunter42";

    public StaffDashboardForm() {
        setTitle("Staff Dashboard");
        setLayout(new GridLayout(4, 2, 10, 10));

        // Initialize UI components
        add(new JLabel("Total Number of Staff:"));
        totalStaffLabel = new JLabel("0");
        add(totalStaffLabel);

        add(new JLabel("Total Number of Departments:"));
        totalDepartmentsLabel = new JLabel("0");
        add(totalDepartmentsLabel);

        add(new JLabel("Total Number of Positions Available:"));
        totalPositionsLabel = new JLabel("0");
        add(totalPositionsLabel);

        // Fetch and display data
        fetchStaffDashboardData();

        pack();
        setLocationRelativeTo(null); // Center the form on the screen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private void fetchStaffDashboardData() {
        try (Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            // Query to get total number of staff
            String totalStaffQuery = "SELECT COUNT(*) FROM staff";
            try (PreparedStatement stmt = conn.prepareStatement(totalStaffQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    totalStaffLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

            // Query to get total number of departments
            String totalDepartmentsQuery = "SELECT COUNT(DISTINCT department) FROM staff";
            try (PreparedStatement stmt = conn.prepareStatement(totalDepartmentsQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    totalDepartmentsLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

            // Query to get total number of positions available
            String totalPositionsQuery = "SELECT COUNT(DISTINCT position) FROM staff";
            try (PreparedStatement stmt = conn.prepareStatement(totalPositionsQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    totalPositionsLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(StaffDashboardForm::new);
    }
}
