package com.dorca.ui.logins;

import com.dorca.beans.AdminBean;
import com.dorca.ui.dashboards.AdminDashboard;

import javax.swing.*;
import java.awt.*;
import java.security.MessageDigest;
import java.sql.*;

public class AdminRegistrationForm extends JFrame {
    // Declare UI components
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JButton registerButton;
    private JButton loginButton;

    // Database connection details
    private final String url = "jdbc:sqlserver://localhost:1433;databaseName=HospitalDB;encrypt=true;trustServerCertificate=true;";
    private final String dbUsername = "hunter";
    private final String dbPassword = "hunter42";

    public AdminRegistrationForm() {
        customInit();
    }

    private void customInit() {
        setTitle("Admin Registration");
        setLayout(new GridLayout(7, 2, 10, 10)); // Increased grid layout rows for new buttons

        // Initialize components
        add(new JLabel("First Name:"));
        firstNameField = new JTextField();
        add(firstNameField);

        add(new JLabel("Last Name:"));
        lastNameField = new JTextField();
        add(lastNameField);

        add(new JLabel("Email:"));
        emailField = new JTextField();
        add(emailField);

        add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        add(passwordField);

        add(new JLabel("Confirm Password:"));
        confirmPasswordField = new JPasswordField();
        add(confirmPasswordField);

        registerButton = new JButton("Register");
        registerButton.addActionListener(e -> registerAdmin());
        add(registerButton);

        loginButton = new JButton("Login");
        loginButton.addActionListener(e -> openLoginDialog());
        add(loginButton);

        pack();
        setLocationRelativeTo(null); // Center the form on the screen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    // Method to register an admin
    private void registerAdmin() {
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());

        // Validate inputs
        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Check if passwords match
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match. Please try again.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Create AdminBean and populate it with data
        AdminBean admin = new AdminBean();
        admin.setFirstName(firstName);
        admin.setLastName(lastName);
        admin.setEmail(email);
        admin.setPassword(hashPassword(password));

        // Save admin data to the database
        if (saveAdminToDatabase(admin)) {
            JOptionPane.showMessageDialog(this, "Admin registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to register admin. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to hash the password
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashedBytes) {
                hexString.append(String.format("%02x", b)); // Convert bytes to hex format
            }
            return hexString.toString(); // Return the hashed password
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Return null if hashing fails
        }
    }

    // Method to save the admin to the database
    private boolean saveAdminToDatabase(AdminBean admin) {
        String query = "INSERT INTO admin (first_name, last_name, email, password) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, admin.getFirstName());
            stmt.setString(2, admin.getLastName());
            stmt.setString(3, admin.getEmail());
            stmt.setString(4, admin.getPassword());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0; // Return true if the record was inserted successfully
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false if an error occurred
        }
    }

    // Method to clear the form fields
    private void clearForm() {
        firstNameField.setText("");
        lastNameField.setText("");
        emailField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
    }

    // Method to open the login dialog
    private void openLoginDialog() {
        JDialog loginDialog = new JDialog(this, "Admin Login", true);
        loginDialog.setLayout(new GridLayout(3, 2, 10, 10));

        // Email and password fields for login
        JTextField loginEmailField = new JTextField();
        JPasswordField loginPasswordField = new JPasswordField();

        loginDialog.add(new JLabel("Email:"));
        loginDialog.add(loginEmailField);

        loginDialog.add(new JLabel("Password:"));
        loginDialog.add(loginPasswordField);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(e -> {
            String email = loginEmailField.getText();
            String password = new String(loginPasswordField.getPassword());

            if (validateAdminLogin(email, password)) {
                JOptionPane.showMessageDialog(loginDialog, "Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                loginDialog.dispose();
                // Proceed to the dashboard after login
                openAdminDashboard();
            } else {
                JOptionPane.showMessageDialog(loginDialog, "Invalid email or password.", "Login Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        loginDialog.add(loginButton);
        loginDialog.setSize(300, 150);
        loginDialog.setLocationRelativeTo(this);
        loginDialog.setVisible(true);
    }

    // Method to validate admin login credentials
    private boolean validateAdminLogin(String email, String password) {
        try (Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            String sql = "SELECT * FROM admin WHERE email = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, email);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    String storedHashedPassword = rs.getString("password");

                    // Compare the entered password with the stored hashed password
                    return storedHashedPassword.equals(hashPassword(password));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    // Method to open the admin dashboard after successful login
    private void openAdminDashboard() {
        new AdminDashboard(); // Open the Admin Dashboard after successful login
        dispose(); // Close the current registration form
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminRegistrationForm::new);
    }
}
