package com.dorca.ui;

import com.dorca.beans.StaffBean;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.text.SimpleDateFormat;

public class StaffManagementForm extends javax.swing.JFrame {

    // Declare custom components
    private JTextField idField, fnameField, lnameField, contactField, emailField;
    private JComboBox<String> positionComboBox, departmentComboBox; // ComboBox for position and department
    private JSpinner dobSpinner;  // For Date of Birth
    private JButton submitButton, refreshButton;
    private JTable staffTable;

    // Database connection details
    private final String url = "jdbc:sqlserver://localhost:1433;databaseName=HospitalDB;encrypt=true;trustServerCertificate=true;";
    private final String username = "hunter";
    private final String password = "hunter42";

    /**
     * Constructor
     */
    public StaffManagementForm() {
        // Calling customInit() for all UI setup
        customInit();
    }

    /**
     * Custom initialization method for manual UI setup
     */
    private void customInit() {
        // Set additional frame properties
        setTitle("Staff Management");
        setLayout(new java.awt.GridLayout(10, 2)); // 8 rows, 2 columns

        // Add components for staff details (Labels on the left, Inputs on the right)
        add(new JLabel("ID No:"));
        idField = new JTextField();
        add(idField);

        add(new JLabel("First Name:"));
        fnameField = new JTextField();
        add(fnameField);

        add(new JLabel("Last Name:"));
        lnameField = new JTextField();
        add(lnameField);

        add(new JLabel("Contact:"));
        contactField = new JTextField();
        add(contactField);

        add(new JLabel("Email:"));
        emailField = new JTextField();
        add(emailField);

        add(new JLabel("Position:"));
        positionComboBox = new JComboBox<>(new String[]{"Manager", "Nurse", "Doctor", "Clerk"});
        add(positionComboBox);

        add(new JLabel("Department:"));
        departmentComboBox = new JComboBox<>(new String[]{"HR", "Finance", "IT", "Medical"});
        add(departmentComboBox);

        // Add Date of Birth field
        add(new JLabel("Date of Birth:"));
        dobSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dobSpinner, "yyyy-MM-dd");
        dobSpinner.setEditor(dateEditor);
        add(dobSpinner);

        submitButton = new JButton("Submit");
        add(submitButton);

        refreshButton = new JButton("Refresh");
        add(refreshButton);

        // Add action listener for submit button
        submitButton.addActionListener(e -> {
            // Create a StaffBean object and populate it with user input
            StaffBean staff = new StaffBean();
            staff.setIdNo(idField.getText());
            staff.setFirstName(fnameField.getText());
            staff.setLastName(lnameField.getText());
            staff.setContact(contactField.getText());
            staff.setEmail(emailField.getText());
            staff.setPosition((String) positionComboBox.getSelectedItem());
            staff.setDepartment((String) departmentComboBox.getSelectedItem());

            // Get the selected DOB and set it in the StaffBean
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String dob = dateFormat.format(dobSpinner.getValue());
            staff.setDob(dob);

            // Insert staff data into the database
            insertStaffData(staff);

            // Show confirmation dialog
            JOptionPane.showMessageDialog(this, "Staff Registered Successfully!");

            // Clear the form after submission
            clearForm();
        });

        // Add action listener for refresh button to load the staff data
        refreshButton.addActionListener(e -> loadStaffData());

        // Initialize staff table
        staffTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(staffTable);
        add(scrollPane);

        // Load staff data when form is opened
        loadStaffData();

        pack(); // Adjust window size to fit content
        setLocationRelativeTo(null); // Center the window on screen
        setVisible(true); // Make the frame visible
    }

    /**
     * Method to insert staff data into the database
     */
    private void insertStaffData(StaffBean staff) {
        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String sql = "INSERT INTO Staff (idNo, firstName, lastName, contact, email, position, department, dob) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                // Set parameters
                stmt.setString(1, staff.getIdNo());
                stmt.setString(2, staff.getFirstName());
                stmt.setString(3, staff.getLastName());
                stmt.setString(4, staff.getContact());
                stmt.setString(5, staff.getEmail());
                stmt.setString(6, staff.getPosition());
                stmt.setString(7, staff.getDepartment());
                stmt.setString(8, staff.getDob());  // Date of Birth

                // Execute the insert statement
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
        }
    }

    /**
     * Method to load staff data into the table
     */
    private void loadStaffData() {
        DefaultTableModel model = new DefaultTableModel(new String[]{"ID No", "First Name", "Last Name", "Contact", "Email", "Position", "Department", "DOB"}, 0);
        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String sql = "SELECT * FROM Staff";
            try (Statement stmt = conn.createStatement()) {
                ResultSet rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    // Add rows to table model
                    model.addRow(new Object[]{
                        rs.getString("idNo"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getString("contact"),
                        rs.getString("email"),
                        rs.getString("position"),
                        rs.getString("department"),
                        rs.getDate("dob")
                    });
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading staff data: " + e.getMessage());
        }
        staffTable.setModel(model); // Set the table model with staff data
    }

    /**
     * Method to clear the form after submission
     */
    private void clearForm() {
        idField.setText("");          // Clear ID field
        fnameField.setText("");       // Clear first name field
        lnameField.setText("");       // Clear last name field
        contactField.setText("");     // Clear contact field
        emailField.setText("");       // Clear email field
        positionComboBox.setSelectedIndex(0);  // Reset position combo box
        departmentComboBox.setSelectedIndex(0); // Reset department combo box
        dobSpinner.setValue(new java.util.Date()); // Reset DOB spinner
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new StaffManagementForm().setVisible(true);
        });
    }
}
