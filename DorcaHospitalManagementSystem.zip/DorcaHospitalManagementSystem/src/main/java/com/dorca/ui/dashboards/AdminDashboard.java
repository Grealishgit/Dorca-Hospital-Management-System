package com.dorca.ui.dashboards;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class AdminDashboard extends JFrame {

    // Database connection details
    private final String url = "jdbc:sqlserver://localhost:1433;databaseName=HospitalDB;encrypt=true;trustServerCertificate=true;";
    private final String dbUsername = "hunter";
    private final String dbPassword = "hunter42";

    // UI components
    private JLabel totalPatientsLabel;
    private JLabel totalDoctorsLabel;
    private JLabel totalStaffLabel;
    private JLabel totalAppointmentsLabel;
    private JLabel totalInventoryLabel; // New label for Inventory count

    public AdminDashboard() {
        customInit();
    }

    private void customInit() {
        setTitle("Admin Dashboard");
        setLayout(new BorderLayout()); // Use BorderLayout for organizing the layout

        // Left Panel with navigation buttons
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS)); // Vertical layout for buttons

        JButton doctorDashboardButton = new JButton("Doctor Dashboard");
        doctorDashboardButton.addActionListener(e -> openDoctorDashboard());
        leftPanel.add(doctorDashboardButton);

        JButton patientDashboardButton = new JButton("Patient Dashboard");
        patientDashboardButton.addActionListener(e -> openPatientDashboard());
        leftPanel.add(patientDashboardButton);

        JButton appointmentDashboardButton = new JButton("Appointment Dashboard");
        appointmentDashboardButton.addActionListener(e -> openAppointmentsDashboard());
        leftPanel.add(appointmentDashboardButton);

        JButton staffDashboardButton = new JButton("Staff Dashboard");
        staffDashboardButton.addActionListener(e -> openStaffDashboard());
        leftPanel.add(staffDashboardButton);

        JButton inventoryDashboardButton = new JButton("Inventory Dashboard");
        inventoryDashboardButton.addActionListener(e -> openInventoryDashboard()); // Open Inventory Dashboard
        leftPanel.add(inventoryDashboardButton);

        // Right Panel with total counts
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new GridLayout(5, 1, 10, 10)); // 5 rows for counts

        totalPatientsLabel = new JLabel("Total Patients: 0");
        rightPanel.add(totalPatientsLabel);

        totalDoctorsLabel = new JLabel("Total Doctors: 0");
        rightPanel.add(totalDoctorsLabel);

        totalStaffLabel = new JLabel("Total Staff: 0");
        rightPanel.add(totalStaffLabel);

        totalAppointmentsLabel = new JLabel("Total Appointments: 0");
        rightPanel.add(totalAppointmentsLabel);

        totalInventoryLabel = new JLabel("Total Inventory Items: 0"); // New label for Inventory Total
        rightPanel.add(totalInventoryLabel);

        // Add panels to the frame
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
        splitPane.setDividerLocation(200); // Set divider location
        add(splitPane);

        // Fetch data from the database
        fetchDashboardData();

        // Frame settings
        setSize(600, 400);
        setLocationRelativeTo(null); // Center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    // Method to fetch dashboard data (total counts)
    private void fetchDashboardData() {
        try (Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            String[] queries = {
                "SELECT COUNT(*) FROM patients", // patients table
                "SELECT COUNT(*) FROM doctors", // doctors table
                "SELECT COUNT(*) FROM staff", // staff table
                "SELECT COUNT(*) FROM appointments", // appointments table
                "SELECT COUNT(*) FROM inventory" // inventory table
            };

            JLabel[] labels = {
                totalPatientsLabel,
                totalDoctorsLabel,
                totalStaffLabel,
                totalAppointmentsLabel,
                totalInventoryLabel
            };

            for (int i = 0; i < queries.length; i++) {
                try (PreparedStatement stmt = conn.prepareStatement(queries[i])) {
                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        labels[i].setText(labels[i].getText().split(":")[0] + ": " + rs.getInt(1));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data from the database.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Methods to open respective dashboards
// Methods to open respective dashboards
private void openDoctorDashboard() {
    DoctorDashboardForm doctorDashboardForm = new DoctorDashboardForm();
    doctorDashboardForm.setVisible(true);
    doctorDashboardForm.setLocationRelativeTo(this);  // Center the new form over AdminDashboard
}

private void openPatientDashboard() {
    PatientDashboardForm patientDashboardForm = new PatientDashboardForm();
    patientDashboardForm.setVisible(true);
    patientDashboardForm.setLocationRelativeTo(this);  // Center the new form over AdminDashboard
}

private void openAppointmentsDashboard() {
    AppointmentsDashboardForm appointmentsDashboardForm = new AppointmentsDashboardForm();
    appointmentsDashboardForm.setVisible(true);
    appointmentsDashboardForm.setLocationRelativeTo(this);  // Center the new form over AdminDashboard
}

private void openStaffDashboard() {
    StaffDashboardForm staffDashboardForm = new StaffDashboardForm();
    staffDashboardForm.setVisible(true);
    staffDashboardForm.setLocationRelativeTo(this);  // Center the new form over AdminDashboard
}

private void openInventoryDashboard() {
    InventoryDashboardForm inventoryDashboardForm = new InventoryDashboardForm();
    inventoryDashboardForm.setVisible(true);
    inventoryDashboardForm.setLocationRelativeTo(this);  // Center the new form over AdminDashboard
}


    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminDashboard::new);
    }

} // <-- Missing closing brace
