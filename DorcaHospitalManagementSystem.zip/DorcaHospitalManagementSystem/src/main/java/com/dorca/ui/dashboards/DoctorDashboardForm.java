package com.dorca.ui.dashboards;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class DoctorDashboardForm extends JFrame {
    private JLabel totalDoctorsLabel;
    private JLabel unavailableDoctorsLabel;
    private JLabel totalSpecialtiesLabel;

    // Database connection details
    private final String url = "jdbc:sqlserver://localhost:1433;databaseName=HospitalDB;encrypt=true;trustServerCertificate=true;";
    private final String dbUsername = "hunter";
    private final String dbPassword = "hunter42";

    public DoctorDashboardForm() {
        setTitle("Doctor Dashboard");
        setLayout(new GridLayout(4, 2, 10, 10));

        // Initialize UI components
        add(new JLabel("Total Doctors Available:"));
        totalDoctorsLabel = new JLabel("0");
        add(totalDoctorsLabel);

        add(new JLabel("Total Doctors Unavailable:"));
        unavailableDoctorsLabel = new JLabel("0");
        add(unavailableDoctorsLabel);

        add(new JLabel("Total Specialties:"));
        totalSpecialtiesLabel = new JLabel("0");
        add(totalSpecialtiesLabel);

        // Fetch and display data
        fetchDoctorDashboardData();

        pack();
        setLocationRelativeTo(null); // Center the form on the screen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private void fetchDoctorDashboardData() {
        try (Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            // Query to get total number of doctors available
            String availableDoctorsQuery = "SELECT COUNT(*) FROM doctors WHERE doctor_availability = 'available'";
            try (PreparedStatement stmt = conn.prepareStatement(availableDoctorsQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    totalDoctorsLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

            // Query to get total number of unavailable doctors
            String unavailableDoctorsQuery = "SELECT COUNT(*) FROM doctors WHERE doctor_availability  = 'unavailable'";
            try (PreparedStatement stmt = conn.prepareStatement(unavailableDoctorsQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    unavailableDoctorsLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

            // Query to get total number of specialties
            String specialtiesQuery = "SELECT COUNT(DISTINCT specialty) FROM doctors";
            try (PreparedStatement stmt = conn.prepareStatement(specialtiesQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    totalSpecialtiesLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DoctorDashboardForm::new);
    }
}
