package com.dorca.ui.dashboards;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class PatientDashboardForm extends JFrame {
    private JLabel scheduledAppointmentsLabel;
    private JLabel completedAppointmentsLabel;
    private JLabel cancelledAppointmentsLabel;

    // Database connection details
    private final String url = "jdbc:sqlserver://localhost:1433;databaseName=HospitalDB;encrypt=true;trustServerCertificate=true;";
    private final String dbUsername = "hunter";
    private final String dbPassword = "hunter42";

    public PatientDashboardForm() {
        setTitle("Patient Dashboard");
        setLayout(new GridLayout(4, 2, 10, 10));

        // Initialize UI components
        add(new JLabel("Total Patients with Scheduled Appointments:"));
        scheduledAppointmentsLabel = new JLabel("0");
        add(scheduledAppointmentsLabel);

        add(new JLabel("Total Patients with Completed Appointments:"));
        completedAppointmentsLabel = new JLabel("0");
        add(completedAppointmentsLabel);

        add(new JLabel("Total Patients with Cancelled Appointments:"));
        cancelledAppointmentsLabel = new JLabel("0");
        add(cancelledAppointmentsLabel);

        // Fetch and display data
        fetchPatientDashboardData();

        pack();
        setLocationRelativeTo(null); // Center the form on the screen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private void fetchPatientDashboardData() {
        try (Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            // Query to get total number of patients with scheduled appointments
            String scheduledQuery = "SELECT COUNT(*) FROM appointments WHERE status = 'scheduled'";
            try (PreparedStatement stmt = conn.prepareStatement(scheduledQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    scheduledAppointmentsLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

            // Query to get total number of patients with completed appointments
            String completedQuery = "SELECT COUNT(*) FROM appointments WHERE status = 'completed'";
            try (PreparedStatement stmt = conn.prepareStatement(completedQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    completedAppointmentsLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

            // Query to get total number of patients with cancelled appointments
            String cancelledQuery = "SELECT COUNT(*) FROM appointments WHERE status = 'cancelled'";
            try (PreparedStatement stmt = conn.prepareStatement(cancelledQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    cancelledAppointmentsLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PatientDashboardForm::new);
    }
}
