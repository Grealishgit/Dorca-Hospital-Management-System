package com.dorca.ui;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class InventoryManagementForm extends javax.swing.JFrame {
    // Declare custom components
    private JTextField itemNameField, quantityField, priceField, supplierField;
    private JButton addButton, updateButton, deleteButton, refreshButton;
    private JTable inventoryTable;
    
    // Database connection details
    private final String url = "jdbc:sqlserver://localhost:1433;databaseName=HospitalDB;encrypt=true;trustServerCertificate=true;";
    private final String username = "hunter";
    private final String password = "hunter42";
    private final String[] commonItems = {
        "Syringe", "Bandage", "Antibiotics", "Gloves", "Gauze", 
        "Oxygen Mask", "Scalpel", "Thermometers", "Stethoscope", "Painkillers"
    };

    public InventoryManagementForm() {
        customInit();
    }

    private void customInit() {
        setTitle("Inventory Management");
        setLayout(new java.awt.GridLayout(7, 2));

        add(new JLabel("Item Name:"));
        itemNameField = new JTextField();
        add(itemNameField);
        
        add(new JLabel("Quantity:"));
        quantityField = new JTextField();
        add(quantityField);
        
        add(new JLabel("Price:"));
        priceField = new JTextField();
        add(priceField);
        
        add(new JLabel("Supplier:"));
        supplierField = new JTextField();
        add(supplierField);
        
        addButton = new JButton("Add Item");
        updateButton = new JButton("Update Item");
        deleteButton = new JButton("Delete Item");
        refreshButton = new JButton("Refresh");
        
        add(addButton);
        add(updateButton);
        add(deleteButton);
        add(refreshButton);

        // Initialize the inventory table
        inventoryTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(inventoryTable);
        add(scrollPane);
        
        loadInventoryData();

        // Add action listeners for buttons
        addButton.addActionListener(e -> addItem());
        updateButton.addActionListener(e -> updateItem());
        deleteButton.addActionListener(e -> deleteItem());
        refreshButton.addActionListener(e -> loadInventoryData());

        // Add a MouseListener to the table for row selection
        inventoryTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Get the selected row index
                int selectedRow = inventoryTable.getSelectedRow();
                if (selectedRow != -1) {
                    // Get the values from the selected row
                    String itemName = String.valueOf(inventoryTable.getValueAt(selectedRow, 1));
                    String quantity = String.valueOf(inventoryTable.getValueAt(selectedRow, 2));
                    String price = String.valueOf(inventoryTable.getValueAt(selectedRow, 3));
                    String supplier = String.valueOf(inventoryTable.getValueAt(selectedRow, 4));

                    // Populate the form with the selected row data
                    itemNameField.setText(itemName);
                    quantityField.setText(quantity);
                    priceField.setText(price);
                    supplierField.setText(supplier);
                }
            }
        });

        pack();
        setLocationRelativeTo(null);  
        setVisible(true);  
    }

    private void addItem() {
        String itemName = itemNameField.getText();
        int quantity = Integer.parseInt(quantityField.getText());
        double price = Double.parseDouble(priceField.getText());
        String supplier = supplierField.getText();

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String sql = "INSERT INTO Inventory (itemName, quantity, price, supplier) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, itemName);
                stmt.setInt(2, quantity);
                stmt.setDouble(3, price);
                stmt.setString(4, supplier);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Item added successfully!");
                loadInventoryData();
                clearForm();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
        }
    }

    private void updateItem() {
        int selectedRow = inventoryTable.getSelectedRow();
        if (selectedRow != -1) {
            String itemId = String.valueOf(inventoryTable.getValueAt(selectedRow, 0));
            String itemName = itemNameField.getText();
            int quantity = Integer.parseInt(quantityField.getText());
            double price = Double.parseDouble(priceField.getText());
            String supplier = supplierField.getText();

            try (Connection conn = DriverManager.getConnection(url, username, password)) {
                String sql = "UPDATE Inventory SET itemName = ?, quantity = ?, price = ?, supplier = ? WHERE itemId = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, itemName);
                    stmt.setInt(2, quantity);
                    stmt.setDouble(3, price);
                    stmt.setString(4, supplier);
                    stmt.setInt(5, Integer.parseInt(itemId));
                    stmt.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Item updated successfully!");
                    loadInventoryData();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an item to update.");
        }
    }

    private void deleteItem() {
        int selectedRow = inventoryTable.getSelectedRow();
        if (selectedRow != -1) {
            String itemId = String.valueOf(inventoryTable.getValueAt(selectedRow, 0));
            try (Connection conn = DriverManager.getConnection(url, username, password)) {
                String sql = "DELETE FROM Inventory WHERE itemId = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, Integer.parseInt(itemId));
                    stmt.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Item deleted successfully!");
                    loadInventoryData();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an item to delete.");
        }
    }

    private void loadInventoryData() {
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"Item ID", "Item Name", "Quantity", "Price", "Supplier", "Last Updated"}, 0);
        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String sql = "SELECT * FROM Inventory";
            try (Statement stmt = conn.createStatement()) {
                ResultSet rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    model.addRow(new Object[]{
                            rs.getInt("itemId"),
                            rs.getString("itemName"),
                            rs.getInt("quantity"),
                            rs.getDouble("price"),
                            rs.getString("supplier"),
                            rs.getTimestamp("lastUpdated")
                    });
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading inventory data: " + e.getMessage());
        }
        inventoryTable.setModel(model);
    }

    private void clearForm() {
        itemNameField.setText("");
        quantityField.setText("");
        priceField.setText("");
        supplierField.setText("");
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new InventoryManagementForm().setVisible(true);
        });
    }
}
