package com.dorca.ui.dashboards;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class InventoryDashboardForm extends JFrame {
    private JLabel totalItemsLabel;
    private JLabel totalSuppliersLabel;
    private JLabel totalPriceLabel;

    // Database connection details
    private final String url = "jdbc:sqlserver://localhost:1433;databaseName=HospitalDB;encrypt=true;trustServerCertificate=true;";
    private final String dbUsername = "hunter";
    private final String dbPassword = "hunter42";

    public InventoryDashboardForm() {
        setTitle("Inventory Dashboard");
        setLayout(new GridLayout(4, 2, 10, 10));

        // Initialize UI components
        add(new JLabel("Total Number of Items:"));
        totalItemsLabel = new JLabel("0");
        add(totalItemsLabel);

        add(new JLabel("Total Number of Suppliers:"));
        totalSuppliersLabel = new JLabel("0");
        add(totalSuppliersLabel);

        add(new JLabel("Total Price of All Items:"));
        totalPriceLabel = new JLabel("0");
        add(totalPriceLabel);

        // Fetch and display data
        fetchInventoryDashboardData();

        pack();
        setLocationRelativeTo(null); // Center the form on the screen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private void fetchInventoryDashboardData() {
        try (Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            // Query to get total number of items
            String totalItemsQuery = "SELECT COUNT(DISTINCT itemId) FROM inventory";
            try (PreparedStatement stmt = conn.prepareStatement(totalItemsQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    totalItemsLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

            // Query to get total number of suppliers
            String totalSuppliersQuery = "SELECT COUNT(DISTINCT supplier) FROM inventory";
            try (PreparedStatement stmt = conn.prepareStatement(totalSuppliersQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    totalSuppliersLabel.setText(String.valueOf(rs.getInt(1)));
                }
            }

            // Query to get total price of all items
            String totalPriceQuery = "SELECT SUM(price) FROM inventory";
            try (PreparedStatement stmt = conn.prepareStatement(totalPriceQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    totalPriceLabel.setText(String.format("%.2f", rs.getDouble(1)));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(InventoryDashboardForm::new);
    }
}
