package com.dorca.beans;

public class StaffBean {
    private String idNo;         // Staff ID number (Primary Key)
    private String firstName;    // First name of the staff
    private String lastName;     // Last name of the staff
    private String contact;      // Contact number of the staff
    private String email;        // Email address of the staff
    private String position;     // Position of the staff
    private String department;   // Department of the staff
    private String dob;          // Date of birth of the staff

    // Getters and setters for all fields

    public String getIdNo() {
        return idNo;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    // Optionally, override toString for display in JComboBox
    @Override
    public String toString() {
        return firstName + " " + lastName;
    }
}
