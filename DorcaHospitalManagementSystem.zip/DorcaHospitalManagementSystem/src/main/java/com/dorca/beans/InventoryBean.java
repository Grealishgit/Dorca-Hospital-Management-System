package com.dorca.beans;

public class InventoryBean {

    // Declare fields for inventory item
    private int itemId;
    private String itemName;
    private int quantity;
    private double price;
    private String supplier;
    private String lastUpdated;

    // No-argument constructor
    public InventoryBean() {
    }

    // Constructor with all fields
    public InventoryBean(int itemId, String itemName, int quantity, double price, String supplier, String lastUpdated) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.quantity = quantity;
        this.price = price;
        this.supplier = supplier;
        this.lastUpdated = lastUpdated;
    }

    // Getter and Setter for itemId
    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    // Getter and Setter for itemName
    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    // Getter and Setter for quantity
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Getter and Setter for price
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    // Getter and Setter for supplier
    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    // Getter and Setter for lastUpdated
    public String getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    @Override
    public String toString() {
        return "InventoryBean{" +
                "itemId=" + itemId +
                ", itemName='" + itemName + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                ", supplier='" + supplier + '\'' +
                ", lastUpdated='" + lastUpdated + '\'' +
                '}';
    }
}
